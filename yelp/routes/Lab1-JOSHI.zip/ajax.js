var testajax=exports.testuser=function(req, res){
	 res.send("WHEEE");
	}